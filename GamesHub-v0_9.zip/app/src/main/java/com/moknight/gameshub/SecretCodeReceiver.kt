package com.moknight.gameshub

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** يفتح ألعابي لما تكتب الكود السري في تطبيق الاتصال (مفيد لما الأيقونة تكون مخفية). */
class SecretCodeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        runCatching {
            context.startActivity(
                Intent(context, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            )
        }
    }
}
