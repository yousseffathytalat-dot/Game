package com.moknight.gameshub

import android.app.Activity
import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Process
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.SecureRandom

/** الجسر بين واجهة الـ HTML والموبايل. بيتنادى من JavaScript على window.Native. */
class NativeBridge(private val act: Activity) {
    private val pm: PackageManager = act.packageManager
    private val sp = act.getSharedPreferences("gameshub", Context.MODE_PRIVATE)

    fun secMode(): String = sp.getString("sec_html", null) ?: sp.getString("sec_mode", "NONE")!!.lowercase()

    // ── حالة الواجهة (نسخة احتياطية من localStorage) ──
    @JavascriptInterface fun save(json: String) { sp.edit().putString("ui_state", json).apply() }
    @JavascriptInterface fun load(): String = sp.getString("ui_state", "") ?: ""

    /** إعدادات الحماية من الإصدارات القديمة (0.7 وقبل). */
    @JavascriptInterface fun legacy(): String = JSONObject()
        .put("sec", sp.getString("sec_mode", "NONE")!!.lowercase())
        .put("code", sp.getString("sec_code", ""))
        .put("qaQ", sp.getString("qa_q", ""))
        .put("qaA", sp.getString("qa_a", ""))
        .toString()

    @JavascriptInterface fun recoveryKey(): String {
        var k = sp.getString("recovery", "") ?: ""
        if (k.isBlank()) {
            val r = SecureRandom()
            k = (1..10).joinToString("") { r.nextInt(10).toString() }
            sp.edit().putString("recovery", k).apply()
        }
        return k
    }

    // ── خيارات الحماية: كلها مقفولة افتراضيًا، ومش بتشتغل غير لما المستخدم يفعّلها ──
    fun optRec() = sp.getBoolean("opt_rec", false)
    fun optShot() = sp.getBoolean("opt_shot", false)
    fun optLock() = sp.getBoolean("opt_lock", false)
    fun iconHidden() = sp.getBoolean("opt_hide", false)

    @JavascriptInterface fun setOpts(json: String) {
        val o = runCatching { JSONObject(json) }.getOrNull() ?: return
        val old = listOf(optRec(), optShot(), optLock(), iconHidden())
        val now = listOf(o.optInt("rec") == 1, o.optInt("shot") == 1, o.optInt("lock") == 1, o.optInt("hide") == 1)
        if (old == now) return
        sp.edit().putBoolean("opt_rec", now[0]).putBoolean("opt_shot", now[1])
            .putBoolean("opt_lock", now[2]).putBoolean("opt_hide", now[3]).apply()
        act.runOnUiThread {
            (act as? MainActivity)?.applyOpts()
            IconAlias.apply(act, secMode(), iconHidden())
        }
    }

    /** الكود اللي بيفتح التطبيق من تطبيق الاتصال لما الأيقونة تكون مخفية (متعرّف في AndroidManifest). */
    @JavascriptInterface fun secretCode(): String = "*#*#1357#*#*"

    @JavascriptInterface fun setSec(mode: String) {
        if (mode == secMode()) return
        sp.edit().putString("sec_html", mode).apply()
        act.runOnUiThread { IconAlias.apply(act, mode, iconHidden()) }
    }

    @JavascriptInterface fun isBeta(): Boolean = false
    @JavascriptInterface fun version(): String = BuildConfig.VERSION_NAME

    @JavascriptInterface fun bars(color: String, lightIcons: Boolean) {
        val c = runCatching { Color.parseColor(color) }.getOrNull() ?: return
        act.runOnUiThread {
            @Suppress("DEPRECATION")
            act.window.statusBarColor = c
            @Suppress("DEPRECATION")
            act.window.navigationBarColor = c
            val v = act.window.decorView
            @Suppress("DEPRECATION")
            v.systemUiVisibility = if (lightIcons) 0
            else android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    // ── إخفاء / إظهار التطبيقات (DevicePolicyManager) ──
    private val dpm: DevicePolicyManager get() = act.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private val admin: ComponentName get() = ComponentName(act, AdminReceiver::class.java)
    private fun isOwner(): Boolean = runCatching { dpm.isDeviceOwnerApp(act.packageName) }.getOrDefault(false)
    private fun isHiddenNow(pkg: String): Boolean =
        isOwner() && runCatching { dpm.isApplicationHidden(admin, pkg) }.getOrDefault(false)
    private fun hidCache(): JSONObject =
        runCatching { JSONObject(sp.getString("hid_cache", "{}") ?: "{}") }.getOrDefault(JSONObject())

    /** حالة الصلاحية + الأمر اللي بيفعّلها مرة واحدة. */
    @JavascriptInterface fun hideStatus(): String = JSONObject()
        .put("owner", isOwner())
        .put("cmd", "adb shell dpm set-device-owner ${act.packageName}/com.moknight.gameshub.AdminReceiver")
        .toString()

    @JavascriptInterface fun hideApps(json: String): String = setHidden(json, true)
    @JavascriptInterface fun unhideApps(json: String): String = setHidden(json, false)

    private fun setHidden(json: String, hide: Boolean): String {
        val ok = JSONArray()
        val fail = JSONArray()
        val pkgs = runCatching { JSONArray(json) }.getOrDefault(JSONArray())
        val owner = isOwner()
        // بيانات الاسم والأيقونة بتتحفظ قبل الإخفاء، علشان التطبيق يفضل ظاهر جوه ألعابي
        val byPkg = HashMap<String, JSONObject>()
        if (owner && hide) {
            val all = JSONArray(apps())
            for (k in 0 until all.length()) all.getJSONObject(k).let { byPkg[it.getString("p")] = it }
        }
        val cache = hidCache()
        for (k in 0 until pkgs.length()) {
            val pkg = pkgs.optString(k)
            if (pkg.isBlank() || pkg == act.packageName || !owner) { fail.put(pkg); continue }
            if (hide) byPkg[pkg]?.let { cache.put(pkg, it) }
            val done = runCatching { dpm.setApplicationHidden(admin, pkg, hide) }.getOrDefault(false)
            if (done) {
                ok.put(pkg)
                if (!hide) cache.remove(pkg)
            } else {
                fail.put(pkg)
                if (hide) cache.remove(pkg)
            }
        }
        sp.edit().putString("hid_cache", cache.toString()).apply()
        return JSONObject().put("ok", ok).put("fail", fail).toString()
    }

    /** يرجّع كل التطبيقات المخفية ويلغي صلاحية Device Owner. */
    @JavascriptInterface fun releaseOwner(): Boolean {
        if (!isOwner()) return false
        val c = hidCache()
        c.keys().forEach { pkg -> runCatching { dpm.setApplicationHidden(admin, pkg, false) } }
        sp.edit().putString("hid_cache", "{}").apply()
        @Suppress("DEPRECATION")
        return runCatching { dpm.clearDeviceOwnerApp(act.packageName); true }.getOrDefault(false)
    }

    @JavascriptInterface fun copyText(t: String) {
        act.runOnUiThread {
            (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("cmd", t))
        }
    }

    // ── تشغيل التطبيقات ──
    @JavascriptInterface fun launch(pkg: String): Boolean {
        // لو التطبيق مخفي، يتظهّر الأول علشان يتشغّل
        if (isHiddenNow(pkg)) runCatching { dpm.setApplicationHidden(admin, pkg, false) }
        val i = pm.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { act.startActivity(i) }.isSuccess
    }

    // ── اللانشر والإحصائيات ──
    @JavascriptInterface fun isLauncher(): Boolean {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == act.packageName
    }

    @JavascriptInterface fun askLauncher() {
        act.runOnUiThread {
            runCatching { act.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                .onFailure { runCatching { act.startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        }
    }

    @JavascriptInterface fun usageGranted(): Boolean {
        val ops = act.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val m = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), act.packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    @JavascriptInterface fun askUsage() {
        act.runOnUiThread { runCatching { act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } }
    }

    // ── قايمة التطبيقات الحقيقية ──
    @Suppress("DEPRECATION")
    private fun isGame(ai: ApplicationInfo) =
        ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0

    private val raceRx = Regex("race|racing|drift|asphalt|kart|speed|rally|fifa|football|soccer|car|سباق", RegexOption.IGNORE_CASE)

    private fun hasInternet(pkg: String): Boolean = runCatching {
        pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS).requestedPermissions
            ?.contains("android.permission.INTERNET") ?: false
    }.getOrDefault(true)

    /** لون مميز من الأيقونة نفسها (متوسط الألوان المشبعة). */
    private fun dominant(b: Bitmap): String {
        val s = Bitmap.createScaledBitmap(b, 8, 8, true)
        var r = 0.0; var g = 0.0; var bl = 0.0; var w = 0.0
        val hsv = FloatArray(3)
        for (x in 0 until 8) for (y in 0 until 8) {
            val p = s.getPixel(x, y)
            val a = Color.alpha(p) / 255.0
            if (a < 0.3) continue
            Color.colorToHSV(p, hsv)
            val wt = a * (0.15 + hsv[1] * hsv[2])
            r += Color.red(p) * wt; g += Color.green(p) * wt; bl += Color.blue(p) * wt; w += wt
        }
        if (w == 0.0) return "#59a8ff"
        return String.format("#%02x%02x%02x", (r / w).toInt(), (g / w).toInt(), (bl / w).toInt())
    }

    @JavascriptInterface fun apps(): String {
        val self = act.packageName
        val usage = if (usageGranted()) {
            val usm = act.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            runCatching { usm.queryAndAggregateUsageStats(now - 30L * 24 * 3600 * 1000, now) }.getOrNull() ?: emptyMap()
        } else emptyMap()
        val now = System.currentTimeMillis()
        val seen = HashSet<String>()
        val out = JSONArray()
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != self }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        for (ri in list) {
            val ai = ri.activityInfo.applicationInfo
            val pkg = ai.packageName
            if (!seen.add(pkg)) continue
            val label = ri.loadLabel(pm).toString()
            val bmp = runCatching { ri.loadIcon(pm).toBitmap(96, 96) }.getOrNull() ?: continue
            val png = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val game = isGame(ai)
            val cat = when {
                !game -> "app"
                raceRx.containsMatchIn(label) || raceRx.containsMatchIn(pkg) -> "race"
                !hasInternet(pkg) -> "off"
                else -> "action"
            }
            val mb = runCatching {
                (listOf(ai.sourceDir) + (ai.splitSourceDirs ?: emptyArray())).sumOf { File(it).length() } / 1048576L
            }.getOrDefault(0L)
            val u = usage[pkg]
            val last = u?.lastTimeUsed ?: 0L
            val ago = if (last > 0) ((now - last) / 86_400_000L).toInt() else 30
            val hours = (u?.totalTimeInForeground ?: 0L) / 3_600_000.0
            out.put(
                JSONObject()
                    .put("p", pkg).put("n", label).put("hid", 0)
                    .put("e", if (game) "pad" else "grid")
                    .put("c", dominant(bmp))
                    .put("mb", mb).put("ago", ago).put("t", last)
                    .put("cat", cat).put("on", if (game) 1 else 0)
                    .put("h", Math.round(hours * 10) / 10.0)
                    .put("i", "data:image/png;base64," + Base64.encodeToString(png.toByteArray(), Base64.NO_WRAP)),
            )
        }
        // التطبيقات المخفية بتفضل ظاهرة جوه ألعابي (من البيانات اللي اتحفظت وقت الإخفاء)
        if (isOwner()) {
            val c = hidCache()
            c.keys().forEach { pkg ->
                if (pkg !in seen && isHiddenNow(pkg)) runCatching { out.put(c.getJSONObject(pkg).put("hid", 1)) }
            }
        }
        return out.toString()
    }
}
