package com.moknight.gameshub

import android.app.Activity
import android.app.AppOpsManager
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Process
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import rikka.shizuku.Shizuku
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.SecureRandom

/** الجسر بين واجهة الـ HTML والموبايل. بيتنادى من JavaScript على window.Native. */
class NativeBridge(private val act: Activity) {
    private val pm: PackageManager = act.packageManager
    private val sp = act.getSharedPreferences("gameshub", Context.MODE_PRIVATE)

    fun secMode(): String = sp.getString("sec_html", null) ?: sp.getString("sec_mode", "NONE")!!.lowercase()

    // ── حالة الواجهة (نسخة احتياطية من localStorage) ──
    @JavascriptInterface fun save(json: String) { sp.edit().putString("ui_state", json).apply() }
    @JavascriptInterface fun load(): String = sp.getString("ui_state", "") ?: ""

    /** إعدادات الحماية من الإصدارات القديمة (0.7 وقبل). */
    @JavascriptInterface fun legacy(): String = JSONObject()
        .put("sec", sp.getString("sec_mode", "NONE")!!.lowercase())
        .put("code", sp.getString("sec_code", ""))
        .put("qaQ", sp.getString("qa_q", ""))
        .put("qaA", sp.getString("qa_a", ""))
        .toString()

    @JavascriptInterface fun recoveryKey(): String {
        var k = sp.getString("recovery", "") ?: ""
        if (k.isBlank()) {
            val r = SecureRandom()
            k = (1..10).joinToString("") { r.nextInt(10).toString() }
            sp.edit().putString("recovery", k).apply()
        }
        return k
    }

    // ── خيارات الحماية: كلها مقفولة افتراضيًا، ومش بتشتغل غير لما المستخدم يفعّلها ──
    fun optRec() = sp.getBoolean("opt_rec", false)
    fun optShot() = sp.getBoolean("opt_shot", false)
    fun optLock() = sp.getBoolean("opt_lock", false)
    fun iconHidden() = sp.getBoolean("opt_hide", false)

    @JavascriptInterface fun setOpts(json: String) {
        val o = runCatching { JSONObject(json) }.getOrNull() ?: return
        val old = listOf(optRec(), optShot(), optLock(), iconHidden())
        val now = listOf(o.optInt("rec") == 1, o.optInt("shot") == 1, o.optInt("lock") == 1, o.optInt("hide") == 1)
        if (old == now) return
        sp.edit().putBoolean("opt_rec", now[0]).putBoolean("opt_shot", now[1])
            .putBoolean("opt_lock", now[2]).putBoolean("opt_hide", now[3]).apply()
        act.runOnUiThread {
            (act as? MainActivity)?.applyOpts()
            IconAlias.apply(act, secMode(), iconHidden())
        }
    }

    /** الكود اللي بيفتح التطبيق من تطبيق الاتصال لما الأيقونة تكون مخفية (متعرّف في AndroidManifest). */
    @JavascriptInterface fun secretCode(): String = "*#*#1357#*#*"

    @JavascriptInterface fun setSec(mode: String) {
        if (mode == secMode()) return
        sp.edit().putString("sec_html", mode).apply()
        act.runOnUiThread { IconAlias.apply(act, mode, iconHidden()) }
    }

    @JavascriptInterface fun isBeta(): Boolean = false
    @JavascriptInterface fun version(): String = BuildConfig.VERSION_NAME

    @JavascriptInterface fun bars(color: String, lightIcons: Boolean) {
        val c = runCatching { Color.parseColor(color) }.getOrNull() ?: return
        act.runOnUiThread {
            @Suppress("DEPRECATION")
            act.window.statusBarColor = c
            @Suppress("DEPRECATION")
            act.window.navigationBarColor = c
            val v = act.window.decorView
            @Suppress("DEPRECATION")
            v.systemUiVisibility = if (lightIcons) 0
            else android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    // ── إخفاء / إظهار التطبيقات (DevicePolicyManager) ──
    private val dpm: DevicePolicyManager get() = act.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private val admin: ComponentName get() = ComponentName(act, AdminReceiver::class.java)
    private fun isOwner(): Boolean = runCatching { dpm.isDeviceOwnerApp(act.packageName) }.getOrDefault(false)
    private fun isHiddenNow(pkg: String): Boolean {
        if (isOwner()) return runCatching { dpm.isApplicationHidden(admin, pkg) }.getOrDefault(false)
        // إخفاء عن طريق Shizuku: التطبيق ظاهر في الكاش ومش ظاهر في قايمة اللانشر وهو لسه موجود على الجهاز
        if (!hidCache().has(pkg) || pm.getLaunchIntentForPackage(pkg) != null) return false
        return runCatching { pm.getApplicationInfo(pkg, PackageManager.MATCH_UNINSTALLED_PACKAGES) != null }.getOrDefault(false)
    }

    // ── Shizuku: إخفاء فعلي من الموبايل نفسه (من غير كمبيوتر ولا إزالة حسابات) ──
    private val SZ_PKG = "moe.shizuku.privileged.api"
    private fun szInstalled(): Boolean = runCatching { pm.getPackageInfo(SZ_PKG, 0); true }.getOrDefault(false)
    private fun szRunning(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
    private fun szReady(): Boolean = runCatching {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    private fun szRun(cmd: String): String = runCatching {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java,
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        out
    }.getOrDefault("")

    private fun szSet(pkg: String, hide: Boolean): Boolean {
        if (!Regex("[A-Za-z0-9_.]+").matches(pkg)) return false
        val out = szRun("pm " + (if (hide) "hide" else "unhide") + " --user 0 " + pkg)
        return out.contains("new hidden state: " + (if (hide) "true" else "false"))
    }

    private fun canHide(): Boolean = isOwner() || szReady()

    private fun setOne(pkg: String, hide: Boolean): Boolean =
        if (isOwner()) runCatching { dpm.setApplicationHidden(admin, pkg, hide) }.getOrDefault(false)
        else szSet(pkg, hide)

    @JavascriptInterface fun shizukuGet() {
        act.runOnUiThread {
            runCatching { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SZ_PKG")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                .onFailure {
                    runCatching { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
        }
    }

    @JavascriptInterface fun shizukuOpen() {
        val i = pm.getLaunchIntentForPackage(SZ_PKG)
        if (i == null) { shizukuGet(); return }
        act.runOnUiThread { runCatching { act.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    }

    @JavascriptInterface fun shizukuAsk() {
        act.runOnUiThread { runCatching { if (Shizuku.pingBinder()) Shizuku.requestPermission(7001) } }
    }
    private fun hidCache(): JSONObject =
        runCatching { JSONObject(sp.getString("hid_cache", "{}") ?: "{}") }.getOrDefault(JSONObject())

    /** حالة الصلاحية + الأمر اللي بيفعّلها مرة واحدة. */
    @JavascriptInterface fun hideStatus(): String = JSONObject()
        .put("owner", canHide())
        .put("via", if (isOwner()) "owner" else if (szReady()) "shizuku" else "")
        .put("shizuku", JSONObject().put("inst", szInstalled()).put("run", szRunning()).put("ok", szReady()))
        .put("sdk", android.os.Build.VERSION.SDK_INT)
        .put("cmd", "adb shell dpm set-device-owner ${act.packageName}/com.moknight.gameshub.AdminReceiver")
        .toString()

    /** يفتح خيارات المطور (علشان تفعّل التصحيح اللاسلكي). */
    @JavascriptInterface fun openDev() {
        act.runOnUiThread {
            runCatching { act.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                .onFailure { runCatching { act.startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) } }
        }
    }

    /** يفتح شاشة الحسابات (لازم تتشال مؤقتًا قبل تفعيل الصلاحية). */
    @JavascriptInterface fun openAccounts() {
        act.runOnUiThread {
            runCatching { act.startActivity(Intent(Settings.ACTION_SYNC_SETTINGS)) }
                .onFailure { runCatching { act.startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        }
    }

    @JavascriptInterface fun hideApps(json: String): String = setHidden(json, true)
    @JavascriptInterface fun unhideApps(json: String): String = setHidden(json, false)

    private fun setHidden(json: String, hide: Boolean): String {
        val ok = JSONArray()
        val fail = JSONArray()
        val pkgs = runCatching { JSONArray(json) }.getOrDefault(JSONArray())
        val owner = canHide()
        // بيانات الاسم والأيقونة بتتحفظ قبل الإخفاء، علشان التطبيق يفضل ظاهر جوه ألعابي
        val byPkg = HashMap<String, JSONObject>()
        if (owner && hide) {
            val all = JSONArray(apps())
            for (k in 0 until all.length()) all.getJSONObject(k).let { byPkg[it.getString("p")] = it }
        }
        val cache = hidCache()
        for (k in 0 until pkgs.length()) {
            val pkg = pkgs.optString(k)
            if (pkg.isBlank() || pkg == act.packageName || !owner) { fail.put(pkg); continue }
            if (hide) byPkg[pkg]?.let { cache.put(pkg, it) }
            val done = setOne(pkg, hide)
            if (done) {
                ok.put(pkg)
                if (!hide) cache.remove(pkg)
            } else {
                fail.put(pkg)
                if (hide) cache.remove(pkg)
            }
        }
        sp.edit().putString("hid_cache", cache.toString()).apply()
        return JSONObject().put("ok", ok).put("fail", fail).toString()
    }

    /** يرجّع كل التطبيقات المخفية ويلغي صلاحية Device Owner. */
    @JavascriptInterface fun releaseOwner(): Boolean {
        if (!isOwner()) {
            // Shizuku: بس رجّع كل التطبيقات المخفية
            if (!szReady()) return false
            val cc = hidCache()
            val names = ArrayList<String>()
            cc.keys().forEach { names.add(it) }
            names.forEach { szSet(it, false) }
            sp.edit().putString("hid_cache", "{}").apply()
            return true
        }
        val c = hidCache()
        c.keys().forEach { pkg -> runCatching { dpm.setApplicationHidden(admin, pkg, false) } }
        sp.edit().putString("hid_cache", "{}").apply()
        @Suppress("DEPRECATION")
        return runCatching { dpm.clearDeviceOwnerApp(act.packageName); true }.getOrDefault(false)
    }

    @JavascriptInterface fun copyText(t: String) {
        act.runOnUiThread {
            (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("cmd", t))
        }
    }

    // ── بوصلة حقيقية: قراءة مباشرة من حساسات أندرويد (دوران + مجال مغناطيسي) ──
    private val sens: SensorManager by lazy { act.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    private var cWant = false
    private var cOn = false
    private var cRot = false
    private var cHasA = false
    private var cHasM = false
    @Volatile private var cHas = false
    @Volatile private var cHx = 0.0
    @Volatile private var cHy = 0.0
    @Volatile private var cAcc = 3
    @Volatile private var cMag = 0.0
    private val cR = FloatArray(9)
    private val cA = FloatArray(3)
    private val cM = FloatArray(3)

    private fun cLow(o: FloatArray, n: FloatArray, first: Boolean) {
        for (i in 0..2) o[i] = if (first) n[i] else o[i] + 0.12f * (n[i] - o[i])
    }

    /** الاتجاه = اتجاه أعلى الشاشة لو الموبايل مفرود، واتجاه ضهر الموبايل لو واقف. بيتحسب من مصفوفة الدوران ويتنعّم كمتجه علشان ما يحصلش قفزة عند 0/360. */
    @Suppress("DEPRECATION")
    private fun cPush() {
        var ux = 0f
        var uy = 1f
        when (act.windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_90 -> { ux = 1f; uy = 0f }
            Surface.ROTATION_180 -> { ux = 0f; uy = -1f }
            Surface.ROTATION_270 -> { ux = -1f; uy = 0f }
        }
        val hx = (cR[0] * ux + cR[1] * uy - cR[2]).toDouble()
        val hy = (cR[3] * ux + cR[4] * uy - cR[5]).toDouble()
        val n = Math.hypot(hx, hy)
        if (n < 1e-3) return
        val x = hx / n
        val y = hy / n
        if (!cHas) { cHx = x; cHy = y; cHas = true }
        else { cHx += (x - cHx) * 0.2; cHy += (y - cHy) * 0.2 }
    }

    private fun cFuse() {
        if (cHasA && cHasM && SensorManager.getRotationMatrix(cR, null, cA, cM)) cPush()
    }

    private val cListener = object : SensorEventListener {
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
            if (sensor?.type == Sensor.TYPE_MAGNETIC_FIELD) cAcc = accuracy
        }

        override fun onSensorChanged(event: SensorEvent?) {
            val e = event ?: return
            when (e.sensor.type) {
                Sensor.TYPE_ROTATION_VECTOR -> if (cRot) {
                    SensorManager.getRotationMatrixFromVector(cR, e.values)
                    cPush()
                }
                Sensor.TYPE_MAGNETIC_FIELD -> {
                    val v = e.values
                    cMag = Math.sqrt((v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).toDouble())
                    if (!cRot) { cLow(cM, v, !cHasM); cHasM = true; cFuse() }
                }
                Sensor.TYPE_ACCELEROMETER -> if (!cRot) { cLow(cA, e.values, !cHasA); cHasA = true; cFuse() }
            }
        }
    }

    private fun cStart() {
        if (cOn) return
        val mag = sens.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) ?: return
        val rot = sens.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val acc = sens.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        cRot = rot != null
        cHas = false; cHasA = false; cHasM = false; cAcc = 3
        cOn = true
        sens.registerListener(cListener, mag, SensorManager.SENSOR_DELAY_GAME)
        if (rot != null) sens.registerListener(cListener, rot, SensorManager.SENSOR_DELAY_GAME)
        else if (acc != null) sens.registerListener(cListener, acc, SensorManager.SENSOR_DELAY_GAME)
    }

    private fun cStop() {
        if (!cOn) return
        cOn = false
        runCatching { sens.unregisterListener(cListener) }
    }

    /** true لو الموبايل فيه حساسات البوصلة. */
    @JavascriptInterface fun compassStart(): Boolean {
        val ok = sens.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) != null &&
            (sens.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null || sens.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null)
        if (!ok) return false
        cWant = true
        act.runOnUiThread { cStart() }
        return true
    }

    @JavascriptInterface fun compassStop() {
        cWant = false
        act.runOnUiThread { cStop() }
    }

    /** "درجة,دقة(0-3),قوة المجال µT" أو نص فاضي لحد ما تيجي أول قراءة. */
    @JavascriptInterface fun compassHeading(): String {
        if (!cHas) return ""
        var h = Math.toDegrees(Math.atan2(cHx, cHy))
        if (h < 0) h += 360.0
        return String.format(java.util.Locale.US, "%.1f,%d,%.0f", h, cAcc, cMag)
    }

    /** بيتنادوا من MainActivity: الحساسات تقف لما الشاشة تتقفل وترجع لو البوصلة لسه مفتوحة. */
    fun pauseSensors() = cStop()
    fun resumeSensors() { if (cWant) cStart() }

    // ── تشغيل التطبيقات ──
    @JavascriptInterface fun launch(pkg: String): Boolean {
        // لو التطبيق مخفي، يتظهّر الأول علشان يتشغّل
        if (isHiddenNow(pkg)) {
            if (setOne(pkg, false)) sp.edit().putString("hid_cache", hidCache().also { it.remove(pkg) }.toString()).apply()
        }
        val i = pm.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startFocus()
        val ok = runCatching { act.startActivity(i) }.isSuccess
        if (!ok) endFocus()
        return ok
    }

    // ── وضع التركيز (عدم الإزعاج وقت اللعب): مقفول لحد ما المستخدم يفعّله ──
    private fun nm() = act.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    @JavascriptInterface fun dndGranted(): Boolean =
        runCatching { nm().isNotificationPolicyAccessGranted }.getOrDefault(false)

    @JavascriptInterface fun askDnd() {
        act.runOnUiThread { runCatching { act.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } }
    }

    @JavascriptInterface fun setFocus(on: Int) {
        if (sp.getBoolean("opt_focus", false) != (on == 1)) sp.edit().putBoolean("opt_focus", on == 1).apply()
    }

    private fun startFocus() {
        if (!sp.getBoolean("opt_focus", false) || !dndGranted()) return
        val n = nm()
        if (!sp.getBoolean("focus_on", false)) {
            val prev = n.currentInterruptionFilter.let { if (it <= 0) NotificationManager.INTERRUPTION_FILTER_ALL else it }
            sp.edit().putInt("focus_prev", prev).putBoolean("focus_on", true).apply()
        }
        runCatching { n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY) }
    }

    /** يرجّع وضع الإشعارات اللي كان قبل التركيز (بيتنادى لما ترجع لألعابي). */
    @JavascriptInterface fun endFocus() {
        if (!sp.getBoolean("focus_on", false)) return
        if (dndGranted()) {
            runCatching { nm().setInterruptionFilter(sp.getInt("focus_prev", NotificationManager.INTERRUPTION_FILTER_ALL)) }
        }
        sp.edit().putBoolean("focus_on", false).apply()
    }

    // ── إحصائيات اللعب (محتاجة إذن الوصول لبيانات الاستخدام) ──
    private fun dayStart(back: Int): Long {
        val c = java.util.Calendar.getInstance()
        c.set(java.util.Calendar.HOUR_OF_DAY, 0); c.set(java.util.Calendar.MINUTE, 0)
        c.set(java.util.Calendar.SECOND, 0); c.set(java.util.Calendar.MILLISECOND, 0)
        c.add(java.util.Calendar.DAY_OF_YEAR, -back)
        return c.timeInMillis
    }

    /** range: day | week | month → [{p, ms, last}] */
    @JavascriptInterface fun usageStats(range: String): String {
        val out = JSONArray()
        if (!usageGranted()) return out.toString()
        val usm = act.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val start = when (range) { "day" -> dayStart(0); "week" -> dayStart(6); else -> dayStart(29) }
        val m = runCatching { usm.queryAndAggregateUsageStats(start, System.currentTimeMillis()) }.getOrNull() ?: return out.toString()
        for ((pkg, u) in m) {
            if (u.totalTimeInForeground > 0 && pkg != act.packageName)
                out.put(JSONObject().put("p", pkg).put("ms", u.totalTimeInForeground).put("last", u.lastTimeUsed))
        }
        return out.toString()
    }

    /** مدة اللعب في آخر 7 أيام (الأقدم أولًا، واليوم آخر واحد) لمجموعة تطبيقات. */
    @JavascriptInterface fun usageDaily(json: String): String {
        val out = JSONArray()
        if (!usageGranted()) { repeat(7) { out.put(0) }; return out.toString() }
        val usm = act.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val pk = HashSet<String>()
        val arr = runCatching { JSONArray(json) }.getOrDefault(JSONArray())
        for (k in 0 until arr.length()) pk.add(arr.optString(k))
        for (back in 6 downTo 0) {
            val a = dayStart(back)
            val b = if (back == 0) System.currentTimeMillis() else dayStart(back - 1)
            val m = runCatching { usm.queryAndAggregateUsageStats(a, b) }.getOrNull() ?: emptyMap()
            var sum = 0L
            for ((pkg, u) in m) if (pkg in pk) sum += u.totalTimeInForeground
            out.put(sum)
        }
        return out.toString()
    }

    // ── تنظيف الألعاب ──
    /** {pkg: [آخر استخدام, تاريخ التثبيت]} للتطبيقات المطلوبة (اللي بتتخطى بتبقى مش موجودة). */
    @JavascriptInterface fun staleInfo(json: String): String {
        val o = JSONObject()
        val arr = runCatching { JSONArray(json) }.getOrDefault(JSONArray())
        val last = HashMap<String, Long>()
        if (usageGranted()) {
            val usm = act.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            runCatching { usm.queryUsageStats(UsageStatsManager.INTERVAL_YEARLY, now - 365L * 86_400_000L, now) }
                .getOrNull()?.forEach { u -> if (u.lastTimeUsed > (last[u.packageName] ?: 0L)) last[u.packageName] = u.lastTimeUsed }
        }
        for (k in 0 until arr.length()) {
            val pkg = arr.optString(k)
            val inst = runCatching { pm.getPackageInfo(pkg, 0).firstInstallTime }.getOrNull() ?: continue
            o.put(pkg, JSONArray().put(last[pkg] ?: 0L).put(inst))
        }
        return o.toString()
    }

    /** بيفتح شاشة المسح بتاعة أندرويد (المستخدم هو اللي بيأكد). */
    @JavascriptInterface fun uninstall(pkg: String) {
        act.runOnUiThread {
            runCatching {
                act.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    // ── اختصارات أيقونة التطبيق (ضغطة مطولة) ──
    @JavascriptInterface fun setShortcuts(json: String) {
        runCatching {
            val sm = act.getSystemService(ShortcutManager::class.java)
            val arr = JSONArray(json)
            if (arr.length() == 0) { sm.removeAllDynamicShortcuts(); return }
            val list = ArrayList<ShortcutInfo>()
            for (k in 0 until minOf(arr.length(), sm.maxShortcutCountPerActivity)) {
                val o = arr.getJSONObject(k)
                val intent = Intent(act, MainActivity::class.java).setAction(Intent.ACTION_VIEW)
                if (o.has("pkg")) intent.putExtra("launch_pkg", o.getString("pkg"))
                if (o.has("folder")) intent.putExtra("open_folder", o.getString("folder"))
                val b = ShortcutInfo.Builder(act, o.getString("id")).setShortLabel(o.getString("label")).setIntent(intent)
                if (o.has("pkg")) runCatching { b.setIcon(Icon.createWithBitmap(pm.getApplicationIcon(o.getString("pkg")).toBitmap(128, 128))) }
                list.add(b.build())
            }
            sm.setDynamicShortcuts(list)
        }
    }

    // ── اللانشر والإحصائيات ──
    @JavascriptInterface fun isLauncher(): Boolean {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == act.packageName
    }

    @JavascriptInterface fun askLauncher() {
        act.runOnUiThread {
            runCatching { act.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                .onFailure { runCatching { act.startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        }
    }

    @JavascriptInterface fun usageGranted(): Boolean {
        val ops = act.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val m = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), act.packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    @JavascriptInterface fun askUsage() {
        act.runOnUiThread { runCatching { act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } }
    }

    // ── قايمة التطبيقات الحقيقية ──
    @Suppress("DEPRECATION")
    private fun isGame(ai: ApplicationInfo) =
        ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0

    private val raceRx = Regex("race|racing|drift|asphalt|kart|speed|rally|fifa|football|soccer|car|سباق", RegexOption.IGNORE_CASE)

    private fun hasInternet(pkg: String): Boolean = runCatching {
        pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS).requestedPermissions
            ?.contains("android.permission.INTERNET") ?: false
    }.getOrDefault(true)

    /** لون مميز من الأيقونة نفسها (متوسط الألوان المشبعة). */
    private fun dominant(b: Bitmap): String {
        val s = Bitmap.createScaledBitmap(b, 8, 8, true)
        var r = 0.0; var g = 0.0; var bl = 0.0; var w = 0.0
        val hsv = FloatArray(3)
        for (x in 0 until 8) for (y in 0 until 8) {
            val p = s.getPixel(x, y)
            val a = Color.alpha(p) / 255.0
            if (a < 0.3) continue
            Color.colorToHSV(p, hsv)
            val wt = a * (0.15 + hsv[1] * hsv[2])
            r += Color.red(p) * wt; g += Color.green(p) * wt; bl += Color.blue(p) * wt; w += wt
        }
        if (w == 0.0) return "#59a8ff"
        return String.format("#%02x%02x%02x", (r / w).toInt(), (g / w).toInt(), (bl / w).toInt())
    }

    @JavascriptInterface fun apps(): String {
        val self = act.packageName
        val usage = if (usageGranted()) {
            val usm = act.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            runCatching { usm.queryAndAggregateUsageStats(now - 30L * 24 * 3600 * 1000, now) }.getOrNull() ?: emptyMap()
        } else emptyMap()
        val now = System.currentTimeMillis()
        val seen = HashSet<String>()
        val out = JSONArray()
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != self }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        for (ri in list) {
            val ai = ri.activityInfo.applicationInfo
            val pkg = ai.packageName
            if (!seen.add(pkg)) continue
            val label = ri.loadLabel(pm).toString()
            val bmp = runCatching { ri.loadIcon(pm).toBitmap(96, 96) }.getOrNull() ?: continue
            val png = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val game = isGame(ai)
            val cat = when {
                !game -> "app"
                raceRx.containsMatchIn(label) || raceRx.containsMatchIn(pkg) -> "race"
                !hasInternet(pkg) -> "off"
                else -> "action"
            }
            val mb = runCatching {
                (listOf(ai.sourceDir) + (ai.splitSourceDirs ?: emptyArray())).sumOf { File(it).length() } / 1048576L
            }.getOrDefault(0L)
            val u = usage[pkg]
            val last = u?.lastTimeUsed ?: 0L
            val ago = if (last > 0) ((now - last) / 86_400_000L).toInt() else 30
            val hours = (u?.totalTimeInForeground ?: 0L) / 3_600_000.0
            out.put(
                JSONObject()
                    .put("p", pkg).put("n", label).put("hid", 0)
                    .put("e", if (game) "pad" else "grid")
                    .put("c", dominant(bmp))
                    .put("mb", mb).put("ago", ago).put("t", last)
                    .put("cat", cat).put("on", if (game) 1 else 0)
                    .put("h", Math.round(hours * 10) / 10.0)
                    .put("i", "data:image/png;base64," + Base64.encodeToString(png.toByteArray(), Base64.NO_WRAP)),
            )
        }
        // التطبيقات المخفية بتفضل ظاهرة جوه ألعابي (من البيانات اللي اتحفظت وقت الإخفاء)
        run {
            val c = hidCache()
            c.keys().forEach { pkg ->
                if (pkg !in seen && isHiddenNow(pkg)) runCatching { out.put(c.getJSONObject(pkg).put("hid", 1)) }
            }
        }
        return out.toString()
    }
}
