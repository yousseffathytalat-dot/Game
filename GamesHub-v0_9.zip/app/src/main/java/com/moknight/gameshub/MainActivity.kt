package com.moknight.gameshub

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader

/**
 * واجهة ألعابي كلها ملف HTML واحد (assets/Games_Hub.html) بيتفتح جوه WebView.
 * الجزء الأصلي (التطبيقات الحقيقية، التشغيل، الأيقونة، الأمان) بيتوصل بالواجهة عن طريق NativeBridge.
 */
class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var bridge: NativeBridge
    private var leftAt = 0L

    /** تثبيت/حذف/تحديث تطبيق: قايمة الإخفاء تتحدّث لوحدها. */
    private val pkgRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            web.post { web.evaluateJavascript("window.__pk&&window.__pk()", null) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bridge = NativeBridge(this)

        val loader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#0C1018"))
            overScrollMode = View.OVER_SCROLL_NEVER
            isHapticFeedbackEnabled = false
            setOnLongClickListener { true }
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                textZoom = 100
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)

                // مفيش خروج من الواجهة لأي موقع تاني
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                    request.url.host != HOST
            }
            addJavascriptInterface(bridge, "Native")
        }
        setContentView(web)
        applyOpts()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(function(){try{return window.__back?String(window.__back()):'false'}catch(e){return 'false'}})()") { r ->
                    if (r?.contains("true") != true) moveTaskToBack(true)
                }
            }
        })

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgRx, f, ContextCompat.RECEIVER_EXPORTED)

        load(intent)
        handleShortcut(intent, true)
    }

    /** اختصار من أيقونة التطبيق: تشغيل لعبة أو فتح فولدر. بيتجاهل لو البوابة مفعّلة. */
    private fun handleShortcut(i: Intent?, cold: Boolean): Boolean {
        val pk = i?.getStringExtra("launch_pkg")
        val fo = i?.getStringExtra("open_folder")
        if (pk == null && fo == null) return false
        if (bridge.secMode() != "none") return false
        if (pk != null) bridge.launch(pk)
        if (fo != null) web.postDelayed({
            web.evaluateJavascript("window.openFolder&&window.openFolder('" + fo.replace("'", "") + "')", null)
        }, if (cold) 1600L else 300L)
        return pk != null
    }

    private fun isHome(i: Intent?) = i?.hasCategory(Intent.CATEGORY_HOME) == true

    private fun load(i: Intent?) {
        bridge.compassStop()
        val hash = if (isHome(i)) "#home" else ""
        web.loadUrl("https://$HOST/assets/Games_Hub.html?t=${System.currentTimeMillis()}$hash")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (handleShortcut(intent, false)) return
        if (isHome(intent)) {
            // زرار Home: افتح تبويب الرئيسية من غير ما تقفل البوابة تاني
            web.evaluateJavascript("window.goHome&&window.goHome()", null)
        } else if (bridge.secMode() != "none") {
            // الأيقونة العادية بتقفل البوابة من جديد
            load(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        // لو غبت أكتر من 30 ثانية والحماية شغالة، البوابة ترجع
        if (leftAt > 0L && System.currentTimeMillis() - leftAt > 30_000L && bridge.secMode() != "none" && bridge.optLock() && !isHome(intent)) {
            load(intent)
        }
    }

    override fun onStop() {
        super.onStop()
        leftAt = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        bridge.resumeSensors()
        bridge.endFocus()
        applyOpts()
        IconAlias.apply(this, bridge.secMode(), bridge.iconHidden())
        web.evaluateJavascript("window.__pk&&window.__pk()", null)
    }

    override fun onPause() {
        bridge.pauseSensors()
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(pkgRx) }
        web.removeJavascriptInterface("Native")
        web.destroy()
        super.onDestroy()
    }

    /** منع لقطة الشاشة وتعتيم المعاينة: بس لو المستخدم فعّلها بنفسه. */
    fun applySecureFlag() {
        if (bridge.optShot()) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    /** خيارات الحماية (إخفاء من المهام الأخيرة + منع اللقطة): مقفولة افتراضيًا. */
    fun applyOpts() {
        applySecureFlag()
        runCatching {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.appTasks.forEach { it.setExcludeFromRecents(bridge.optRec()) }
        }
    }

    companion object {
        const val HOST = "appassets.androidplatform.net"
    }
}
