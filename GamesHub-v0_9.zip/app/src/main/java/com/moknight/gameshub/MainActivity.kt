package com.moknight.gameshub

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader

/**
 * واجهة ألعابي كلها ملف HTML واحد (assets/Games_Hub.html) بيتفتح جوه WebView.
 * الجزء الأصلي (التطبيقات الحقيقية، التشغيل، الأيقونة، الأمان) بيتوصل بالواجهة عن طريق NativeBridge.
 */
class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var bridge: NativeBridge
    private var leftAt = 0L

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bridge = NativeBridge(this)

        val loader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#0C1018"))
            overScrollMode = View.OVER_SCROLL_NEVER
            isHapticFeedbackEnabled = false
            setOnLongClickListener { true }
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                textZoom = 100
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)

                // مفيش خروج من الواجهة لأي موقع تاني
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                    request.url.host != HOST
            }
            addJavascriptInterface(bridge, "Native")
        }
        setContentView(web)
        applySecureFlag()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(function(){try{return window.__back?String(window.__back()):'false'}catch(e){return 'false'}})()") { r ->
                    if (r?.contains("true") != true) moveTaskToBack(true)
                }
            }
        })

        load(intent)
    }

    private fun isHome(i: Intent?) = i?.hasCategory(Intent.CATEGORY_HOME) == true

    private fun load(i: Intent?) {
        val hash = if (isHome(i)) "#home" else ""
        web.loadUrl("https://$HOST/assets/Games_Hub.html?t=${System.currentTimeMillis()}$hash")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (isHome(intent)) {
            // زرار Home: افتح تبويب الرئيسية من غير ما تقفل البوابة تاني
            web.evaluateJavascript("window.goHome&&window.goHome()", null)
        } else if (bridge.secMode() != "none") {
            // الأيقونة العادية بتقفل البوابة من جديد
            load(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        // لو غبت أكتر من 30 ثانية والحماية شغالة، البوابة ترجع
        if (leftAt > 0L && System.currentTimeMillis() - leftAt > 30_000L && bridge.secMode() != "none" && !isHome(intent)) {
            load(intent)
        }
    }

    override fun onStop() {
        super.onStop()
        leftAt = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        applySecureFlag()
        IconAlias.apply(this, bridge.secMode())
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("Native")
        web.destroy()
        super.onDestroy()
    }

    /** مع الأمان: ما يظهرش في شاشة التطبيقات الأخيرة ولا في لقطات الشاشة. */
    fun applySecureFlag() {
        if (bridge.secMode() != "none") window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    companion object {
        const val HOST = "appassets.androidplatform.net"
    }
}
