package com.moknight.gameshub

import android.app.admin.DeviceAdminReceiver

/** مستقبل إدارة الجهاز: لما ألعابي يتفعّل كـ Device Owner يقدر يخفي ويظهر التطبيقات فعليًا (DevicePolicyManager.setApplicationHidden). */
class AdminReceiver : DeviceAdminReceiver()
