package com.moknight.gameshub

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/** يغيّر اسم وأيقونة التطبيق في درج التطبيقات حسب طريقة الحماية (activity-alias). ما بيمسح ولا بيفك تثبيت أي حاجة. */
object IconAlias {
    // كلاسات الـ alias متعرّفة تحت الـ namespace الثابت، حتى مع النسخة التجريبية اللي applicationId بتاعها مختلف
    private const val NS = "com.moknight.gameshub"

    private val byMode = mapOf(
        "none" to "AliasDefault",
        "compass" to "AliasCompass",
        "calc" to "AliasCalc",
        "dialer" to "AliasDialer",
        "qa" to "AliasQa",
        "crash" to "AliasCrash",
        "timer" to "AliasTimer",
        "weather" to "AliasWeather",
        "torch" to "AliasTorch",
        "level" to "AliasLevel",
        "notes" to "AliasNotes",
        "scan" to "AliasScan",
        "piano" to "AliasPiano",
        "clock" to "AliasClock",
        "tasbih" to "AliasTasbih",
        "paint" to "AliasPaint",
    )

    /** hide = true: كل الـ aliases تتقفل والأيقونة تختفي من الرئيسية والدرج (التطبيق يفضل متثبت). */
    fun apply(ctx: Context, mode: String, hide: Boolean = false) {
        val pm = ctx.packageManager
        val want: String? = if (hide) null else (byMode[mode] ?: "AliasDefault")
        fun cn(n: String) = ComponentName(ctx.packageName, "$NS.$n")
        fun enabled(n: String): Boolean {
            val s = pm.getComponentEnabledSetting(cn(n))
            return if (s == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT) n == "AliasDefault"
            else s == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        }
        runCatching {
            // الأول فعّل المطلوب علشان ما يفضلش التطبيق من غير أيقونة
            if (want != null && !enabled(want)) {
                pm.setComponentEnabledSetting(cn(want), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            }
            byMode.values.filter { it != want && enabled(it) }.forEach {
                pm.setComponentEnabledSetting(cn(it), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
        }
    }
}
